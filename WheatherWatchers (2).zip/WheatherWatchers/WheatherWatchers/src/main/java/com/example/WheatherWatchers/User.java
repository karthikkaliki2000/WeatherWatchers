package com.example.WheatherWatchers;

public interface User {
	public void setUserDetails(String name,int age);
	public void setLocationDetails(Location location);
	public String getWeatherForecastForLocation();

}
