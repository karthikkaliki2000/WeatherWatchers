package com.example.WheatherWatchers;

public class myLocation implements Location {
	String City;

	String state;

	String country;

	public void init() {
		System.out.println("The location has been Instantiated I am init() method");
	}

	@Override
	public void setLocation(String City,String state,String country) {
		// TODO Auto-generated method stub
		this.City=City;
		this.state=state;
		this.country=country;

	}

	@Override
	public String getLocation() {
		// TODO Auto-generated method stub
		return this.City;
	}

}
