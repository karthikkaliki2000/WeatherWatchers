package com.example.WheatherWatchers;

import java.util.List;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;



//@SpringBootApplication
public class WheatherWatchersApplication {

	public static void main(String[] args) {
		//SpringApplication.run(WheatherWatchersApplication.class, args);
		ClassPathXmlApplicationContext con = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Scanner s = new Scanner(System.in);
		System.out.println("Welcome to Weather Application");
		System.out.println("Please enter your name:");
		String name = s.nextLine();
		System.out.println("Enter your age:");
		int age = s.nextInt();
		s.nextLine();
		System.out.println("Enter your city:");
		String city = s.nextLine();
		System.out.println("Enter your state:");
		String state = s.nextLine();
		System.out.println("Enter your country:");
		String country = s.nextLine();
		User user=(User)con.getBean("myUser");
		user.setUserDetails(name, age);
		Location location=(Location)con.getBean("myLocation");
		location.setLocation(city, state, country);
		user.setLocationDetails(location);
		System.out.println(user.getWeatherForecastForLocation());
		s.close();
		con.close();
	}

}
