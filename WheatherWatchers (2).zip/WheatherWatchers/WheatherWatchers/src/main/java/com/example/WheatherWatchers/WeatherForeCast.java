package com.example.WheatherWatchers;

public interface WeatherForeCast {
	public String getWheather();
}
