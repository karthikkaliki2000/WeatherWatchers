package com.example.WheatherWatchers;

public interface Location {
	public void setLocation(String City,String state,String country);
	public String getLocation();
	
}
