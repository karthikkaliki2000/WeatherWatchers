package com.example.WheatherWatchers;

public class myUser implements User {
	String name;
	int age;
	Location location;
	WeatherForeCast weatherForecast ;
	public void init() {
		System.out.println("\"The user has been Instantiated I am init() method\"");
	}
	public void destroy() {
		System.out.println("User destroyed");
	}
	public void setWeatherForecast(WeatherForeCast weatherForecast) {
		this.weatherForecast = weatherForecast;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	@Override
	public void setUserDetails(String name,int age) {
		// TODO Auto-generated method stub
		this.name=name;
		this.age=age;
		
	}

	

	@Override
	public String getWeatherForecastForLocation() {
		// TODO Auto-generated method stub
		return "Hi "+this.name+" weather in your city "+location.getLocation()+" is "+weatherForecast.getWheather();
	}
	@Override
	public void setLocationDetails(Location location) {
		// TODO Auto-generated method stub
		this.location=location;
		
	}
	

}
