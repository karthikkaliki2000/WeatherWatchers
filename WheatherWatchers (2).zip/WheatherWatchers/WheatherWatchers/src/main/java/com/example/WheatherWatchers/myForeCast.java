package com.example.WheatherWatchers;

import java.util.ArrayList;
import java.util.Random;

public class myForeCast implements WeatherForeCast {
	String [] arr= { "sunny",  
	        "cloudy", "windy", "snowy", "rainy"};
	
	@Override
	public String getWheather() {
		// TODO Auto-generated method stub
		int randIndex=new Random().nextInt(arr.length);
		return arr[randIndex];
	}

}
